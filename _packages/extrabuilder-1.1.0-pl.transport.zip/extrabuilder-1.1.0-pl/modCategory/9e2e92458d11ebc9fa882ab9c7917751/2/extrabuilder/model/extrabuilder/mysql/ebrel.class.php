<?php
require_once (dirname(__DIR__) . '/ebrel.class.php');
class ebRel_mysql extends ebRel {}