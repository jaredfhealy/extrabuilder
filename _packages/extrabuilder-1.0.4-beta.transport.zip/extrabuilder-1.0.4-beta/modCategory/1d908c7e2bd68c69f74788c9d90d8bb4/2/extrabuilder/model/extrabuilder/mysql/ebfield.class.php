<?php
require_once (dirname(__DIR__) . '/ebfield.class.php');
class ebField_mysql extends ebField {}