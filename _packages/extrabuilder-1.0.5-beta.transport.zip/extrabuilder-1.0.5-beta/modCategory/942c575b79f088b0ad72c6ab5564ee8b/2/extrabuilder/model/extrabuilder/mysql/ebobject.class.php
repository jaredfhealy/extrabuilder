<?php
require_once (dirname(__DIR__) . '/ebobject.class.php');
class ebObject_mysql extends ebObject {}