<?php
require_once (dirname(__DIR__) . '/ebpackage.class.php');
class ebPackage_mysql extends ebPackage {}