<?php
require_once (dirname(__DIR__) . '/ebtransport.class.php');
class ebTransport_mysql extends ebTransport {}