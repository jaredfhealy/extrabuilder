<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'ebPackage',
    1 => 'ebObject',
    2 => 'ebField',
    3 => 'ebRel',
    4 => 'ebTransport',
  ),
);