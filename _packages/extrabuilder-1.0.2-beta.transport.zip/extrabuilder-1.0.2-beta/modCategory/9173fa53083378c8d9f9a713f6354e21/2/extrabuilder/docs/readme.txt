Manage Packages and Tables
This Extra allows you to build tables, packages and transport them to other instances. Or even publish to the MODX Extras directory for the community to utilize.
