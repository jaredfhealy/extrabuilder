<?php
class ebTransport extends xPDOSimpleObject {}