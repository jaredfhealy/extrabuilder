<?php
class ebPackage extends xPDOSimpleObject {}