<?php
class ebField extends xPDOSimpleObject {}