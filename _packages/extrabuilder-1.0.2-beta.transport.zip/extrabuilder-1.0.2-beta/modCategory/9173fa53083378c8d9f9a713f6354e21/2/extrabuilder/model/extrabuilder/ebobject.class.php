<?php
class ebObject extends xPDOSimpleObject {}