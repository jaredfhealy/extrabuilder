<?php
class ebRel extends xPDOSimpleObject {}