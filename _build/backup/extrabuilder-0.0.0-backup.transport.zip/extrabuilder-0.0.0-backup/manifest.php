<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Backup',
    'readme' => 'Backup',
    'changelog' => 'Backup',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => 'ee92cc35772d70f35849b78e3e976d97',
      'native_key' => 'ExtraBuilder',
      'filename' => 'MODX/Revolution/modNamespace/61f923cd278f6ecb3a3f5f55081066a0.vehicle',
      'namespace' => 'ExtraBuilder',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => 'dcd0a1191c51f57ab411538e2d96a978',
      'native_key' => 'ExtraBuilder',
      'filename' => 'MODX/Revolution/modMenu/be7f30b5363bc7f0bd952781f9208770.vehicle',
      'namespace' => 'ExtraBuilder',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '4954de8f01c0072002fe8044b49548ea',
      'native_key' => 'Package Builder',
      'filename' => 'MODX/Revolution/modMenu/2386bb8bc5a9e8253040a468dc6edf02.vehicle',
      'namespace' => 'ExtraBuilder',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => 'dbe3203925a7ec0b4fa053b1652f80e7',
      'native_key' => 'Transport Builder',
      'filename' => 'MODX/Revolution/modMenu/b7a3cdf5444a7f978399f9b77bab68ea.vehicle',
      'namespace' => 'ExtraBuilder',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => 'a8558702beecc0da6e400392ed572140',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/331945abd942d15884898509f584d84b.vehicle',
      'namespace' => 'ExtraBuilder',
    ),
  ),
);