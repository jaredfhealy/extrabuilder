<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Backup',
    'readme' => 'Backup',
    'changelog' => 'Backup',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '04bc2c71ff6c3d4756c412eb00291a32',
      'native_key' => 'extrabuilder',
      'filename' => 'modNamespace/4c021790a4337e375a1c7b1faa11ef64.vehicle',
      'namespace' => 'extrabuilder',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '0ddd24deb80dd943b191095977608eec',
      'native_key' => 'ExtraBuilder',
      'filename' => 'modMenu/775bd39a69100cc4440b78e6d646e34d.vehicle',
      'namespace' => 'extrabuilder',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '1b8d726b3ca19a69a37a9e983c28858d',
      'native_key' => 'Package Builder',
      'filename' => 'modMenu/0bac902c16ab3511f07fd968475a57b5.vehicle',
      'namespace' => 'extrabuilder',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a66f766ca011bd60da97d07b0d6c7928',
      'native_key' => 'Transport Builder',
      'filename' => 'modMenu/b450e87a77f4fc14e131b7fb861f6b6d.vehicle',
      'namespace' => 'extrabuilder',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '7d8f86fa1e7078bec253c2331726f5c6',
      'native_key' => NULL,
      'filename' => 'modCategory/f7d26e929e9f518cdd06917e0af1ef7a.vehicle',
      'namespace' => 'extrabuilder',
    ),
  ),
);