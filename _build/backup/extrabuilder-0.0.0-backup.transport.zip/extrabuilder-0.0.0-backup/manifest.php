<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '1809d5557618c36fde3c36e8e582f07f',
      'native_key' => 'extrabuilder',
      'filename' => 'MODX/Revolution/modNamespace/cfd17a632dcd578a0dbdddeba75beac9.vehicle',
      'namespace' => 'extrabuilder',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '17251fa4f264f6f18dcdf45ead113e69',
      'native_key' => 'extrabuilder.menu.main',
      'filename' => 'MODX/Revolution/modMenu/43056232b4037f4e5638f2176b0f7b47.vehicle',
      'namespace' => 'extrabuilder',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => 'a5789df03ec18d55c9688d7ef15754ca',
      'native_key' => 'extrabuilder.menu.package',
      'filename' => 'MODX/Revolution/modMenu/5da9e4d47498ebb64432184189d81af4.vehicle',
      'namespace' => 'extrabuilder',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => 'a6b275512ce2327bd8f1f29f76b6eacc',
      'native_key' => 'extrabuilder.menu.transport',
      'filename' => 'MODX/Revolution/modMenu/4986048589c7214b9bcffba0fb4c6868.vehicle',
      'namespace' => 'extrabuilder',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => 'd0d6eea1960c9c94caef5d68524526f8',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/38b5b071688767b682a5b3471ba1f82e.vehicle',
      'namespace' => 'extrabuilder',
    ),
  ),
);