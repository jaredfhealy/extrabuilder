<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Backup',
    'readme' => 'Backup',
    'changelog' => 'Backup',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'fe090ed9b83cebdf8fcd0bae3754872a',
      'native_key' => 'extrabuilder',
      'filename' => 'modNamespace/311ad01ce3e4bf902ef91212270f5b25.vehicle',
      'namespace' => 'extrabuilder',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '3be37efc9924c23fdf08fa3acce5de5a',
      'native_key' => 'ExtraBuilder',
      'filename' => 'modMenu/ec9aff4336309dfe6ba3c4f61c60a8e0.vehicle',
      'namespace' => 'extrabuilder',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '3fd640cff5664f09dfead84e803cdaad',
      'native_key' => 'Package Builder',
      'filename' => 'modMenu/9830de5f81188df76cf25ef26d5cfa61.vehicle',
      'namespace' => 'extrabuilder',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '093313af35e58acfea14a2d051b4f4ce',
      'native_key' => 'Transport Builder',
      'filename' => 'modMenu/e406665a94e3bb9ca50465c1ae0301bf.vehicle',
      'namespace' => 'extrabuilder',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'd1f15d18d73250ece5b99b89c1438fd5',
      'native_key' => NULL,
      'filename' => 'modCategory/138f57557aaebaf0007bbf3eb500c38e.vehicle',
      'namespace' => 'extrabuilder',
    ),
  ),
);