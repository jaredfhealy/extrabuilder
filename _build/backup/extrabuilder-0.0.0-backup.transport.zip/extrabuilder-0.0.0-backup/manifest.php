<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Backup',
    'readme' => 'Backup',
    'changelog' => 'Backup',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => 'd82eb273e0762c1c9354cd9621568888',
      'native_key' => 'extrabuilder',
      'filename' => 'MODX/Revolution/modNamespace/eeed95697305c2ae4bbf9e261761f282.vehicle',
      'namespace' => 'extrabuilder',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '10df9e40e9ef872645234233419a8c48',
      'native_key' => 'extrabuilder.menu.main',
      'filename' => 'MODX/Revolution/modMenu/71e32d7d46786937f76e6348806458d9.vehicle',
      'namespace' => 'extrabuilder',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => 'b522542837f262e5e1a6ef6fed357777',
      'native_key' => 'extrabuilder.menu.package',
      'filename' => 'MODX/Revolution/modMenu/45ee79d7bc0c6246f525c1c48b475476.vehicle',
      'namespace' => 'extrabuilder',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '4d720ced02fddfd1c86bff28eeabeb05',
      'native_key' => 'extrabuilder.menu.transport',
      'filename' => 'MODX/Revolution/modMenu/2256f55857a4fe70eee37e684fcbcfae.vehicle',
      'namespace' => 'extrabuilder',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => '25d67384c67d62612aba5ad336c72176',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/632a03922aae48598bc2e066344f186c.vehicle',
      'namespace' => 'extrabuilder',
    ),
  ),
);